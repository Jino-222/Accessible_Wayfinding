Overleaf → New Project → Upload Project → ZIP 선택
Main document: main.tex / Compiler: XeLaTeX
320×180mm 가로형 9쪽 / 제품 개발 사례집 형식 / 화면·도식·실험 그래프 중심의 개조식 본문

구성
1. 프로젝트 개요
2. 가족의 유모차 이동 불편
3. 교통 실무·AI 개발 경험
4. AR 서비스 구상과 선행 사례
5. 실제 이미지·합성 RGB·모의 관측의 구분
6. 웹 직접 이동과 중단·재개 시험
7. 측정 성과
8. 실패·수정·학습
9. AIGEN 참여 후 현장 검증·확장 목표

GitHub: https://github.com/Jino-222/Accessible_Wayfinding
웹: https://jino-222.github.io/Accessible_Wayfinding/
계산 기준·검증 범위: METHODS_KO.txt / 실행 근거: evidence/
6쪽: 정상 화면을 크게 배치하고 관측 끊김·복구·접근 중단의 실제 화면을 비교
화면 속 UI 문구: 원본 유지 / 편집 본문: 개조식
